class PatientRecordController < ApplicationController
  def expand(id)
     id
  end
end